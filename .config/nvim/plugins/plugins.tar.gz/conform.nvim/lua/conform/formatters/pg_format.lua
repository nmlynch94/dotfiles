---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/darold/pgFormatter",
    description = "PostgreSQL SQL syntax beautifier.",
  },
  command = "pg_format",
}
