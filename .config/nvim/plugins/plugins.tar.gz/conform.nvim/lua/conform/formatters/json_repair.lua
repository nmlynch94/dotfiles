---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/mangiucugna/json_repair",
    description = "A python module to repair invalid JSON from LLMs.",
  },
  command = "json_repair",
  args = {},
}
