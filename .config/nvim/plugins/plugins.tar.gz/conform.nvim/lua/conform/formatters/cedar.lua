---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/cedar-policy/cedar",
    description = "Formats cedar policies.",
  },
  command = "cedar",
  args = "format",
}
