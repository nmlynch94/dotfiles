---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/reteps/dockerfmt",
    description = "Dockerfile formatter. a modern dockfmt.",
  },
  command = "dockerfmt",
}
