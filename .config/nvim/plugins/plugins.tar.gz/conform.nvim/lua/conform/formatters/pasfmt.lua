---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/integrated-application-development/pasfmt",
    description = "Delphi code formatter.",
  },
  command = "pasfmt",
  args = {},
  stdin = true,
}
