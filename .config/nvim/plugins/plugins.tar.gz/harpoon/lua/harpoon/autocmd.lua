local augroup = vim.api.nvim_create_augroup
return augroup("Harpoon", {})
