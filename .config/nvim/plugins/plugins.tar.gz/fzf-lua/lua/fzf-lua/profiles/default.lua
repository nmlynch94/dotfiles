return {
  desc = "fzf-lua default options",
  { "border-fused", "hide" },
}
