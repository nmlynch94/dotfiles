return {
    ["dummy"] = "dummy-registry.dummy",
    ["dummy2"] = "dummy-registry.dummy2",
    ["registry"] = "dummy-registry.registry",
}
